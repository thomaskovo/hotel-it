<!DOCTYPE html>
<html>
<head>
<title>Home</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    <!-- STYLES -->
    <link  href="https://fonts.googleapis.com/css?family=Open+Sans:300,800" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet"  type="text/css" href="css/reset.css">
    
    <link rel="stylesheet" type="text/css" href="css/style.css">
    
</head>

<body>
    <?php include 'header.php';?>
    
    <div id="photo" >
        <div class="center">
            <h1>HOTEL IT</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore. sed do eiusmod tempor incididunt ut labore et dolore</p>
        </div>
    </div>
    <section>
        kjbwkjbf
    </section>
    <footer>
        © 2017 Hotel it. All Rights Reserved.
    </footer>
    
    <!-- SCRIPTS -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/script.js"></script>
    
    
    
</body>

</html>