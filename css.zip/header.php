<div id="dim">
        
        </div>
    <div id="list">
        <div class="hlist list_item">Menu<i class="fa fa-times" aria-hidden="true"></i></div>
        <div class="scrollpane">
        <a class="list_item">IT Bussiness Solutions</a>
            <div class="sublist_item">Cloud and Hosted Solutions</div>
            <div class="sublist_item">Hardware as a Service (HaaS)</div>
            <div class="sublist_item">On Demand Support</div>
            <div class="sublist_item">Network Design and Implementation</div>
            <a href="IT_Bussiness_Solutions/hosted_exchange_office_365.html">Hostovaný Exchange &amp; Office 365</a> 
            
            <div class="sublist_item">Backup Storage and Disaster Recovery</div>
            <div class="sublist_item">Project Design, Development Management</div>
         <a class="list_item">Asset Security</a>   
            <div class="sublist_item">Door Access System</div>
            <div class="sublist_item">CCTV</div>
            <div class="sublist_item">GDPR Consulting</div>
        <a class="list_item ">Hotel IT Management</a>   
            <div class="sublist_item">Process Management</div>
            <div class="sublist_item">Cloud-based PMS Software</div>
            <div class="sublist_item">Sound Systems</div>    
            <div class="sublist_item">IT Management &amp; Support</div> 
        <a class="list_item ">IT Facility</a>   
            <div class="sublist_item">Pasportisaion &amp; Inventarisation</div>
            <div class="sublist_item">Help Desk</div>
            <div class="sublist_item">Inteligentne Merace</div>    
            <div class="sublist_item">Planned maintenance</div>        
        </div>
    </div>
    <header >
        <div id="top_bar">
            
            <div class="sk flag"></div>
            <div class="en flag"></div>
            <div id="phone">
                <a href="callto:00421 904 555 555">
                    <i class="fa fa-phone" aria-hidden="true"></i> +421 904 555 555
                </a>
            </div>
            <a href="mailto:email@email.com">
                <div id="email"><i class="fa fa-envelope" aria-hidden="true"></i> email@email.com</div>
            </a>
        </div>
        <div id="main_bar">
            <div class="lang"></div>
            <div class="lang_drop">
                <div class="en flag"></div>
                English
            </div>
            <div id="logo">
            </div>
            <ul id="links">
                <li class="dropdown" >
                    <a id="a_home" href="#home">Home</a>
                    <div class="dropdown-content">
                        <a>About us</a>
                        <a>Contact</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a id="a_bussiness" href="IT_Bussiness_Solutions/">IT Bussiness Solutions</a>
                    <div class="dropdown-content">
                        <a>Cloud and Hosted Solutions</a>
                        <a>Projects &amp; Support</a>
                        <a>Network Design and Implementation</a>
                        <a href="IT_Bussiness_Solutions/hosted_exchange_office_365.html">Hosted Exchange &amp; Office 365</a>
                        <a>Backup &amp; Recovery</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a id="a_security" href="#contact">Asset Security</a>
                    <div class="dropdown-content">
                        <a>Door Access Security</a>
                        <a>CCTV</a>
                        <a>GDPR Consulting</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a id="a_management" href="#contact">Hotel IT Management</a>
                    <div class="dropdown-content">
                        <a>Process Management</a>
                        <a>Cloud-based PMS Software</a>
                        <a>Sound Systems</a>
                        <a>IT Management &amp; Support</a>
                    </div>
                </li>
                <li class="dropdown">
                    <a id="a_facility" href="#contact">IT Facility</a>
                    <div class="dropdown-content">
                        <a>Pasportizacia &amp; Inventarizacia</a>
                        <a>Help Desk</a>
                        <a>Inteligentne merace</a>
                        <a>Planovana udrzba</a>
                    </div>
                </li>
                <li><a id="menuButton"><i class="fa fa-bars"></i></a></li>
            </ul>
        </div>
    </header>